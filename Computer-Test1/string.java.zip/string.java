
/**
 * Write a description of class string here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class string
{
    public static void main(String[]args){
        String name="Elijah";
        
        System.out.print(name.substring(0,1));
        System.out.print(name.substring(5,6));
        System.out.println(name.substring(1,5));
        
        String first= "Elijah";
        String last= "Griffith";
        
        
        
        System.out.print(first.substring(0,1));
        System.out.print(last.substring(0,1));
        
    System.out.println();
    }
    
}
