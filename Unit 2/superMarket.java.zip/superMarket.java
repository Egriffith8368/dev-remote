public class superMarket {
    private double cost;
    private double cou;
    private double total;


    public superMarket(double _cost){
        cost=_cost;


    }

    public void calc(){
        if (cost<10){
            
            System.out.println("No Coupon");

        
        }
        else if (cost>9 && cost<=60){
            cou= cost*.8;
            
        }
        else if (cost>60 && cost<151){
            cou= cost*.10;
            
        }
        else if (cost>150 && cost<=210){
            cou= cost*.12;
        }
        else if (cost>210){
            cou=cost*.14;
        }
        else{

        System.out.println("ERROR: Could not calculate coupon amount");
        }
    }




    public String toString(){
        total=cost-cou;
        return("Your total cost is "+ total);
    }
}
