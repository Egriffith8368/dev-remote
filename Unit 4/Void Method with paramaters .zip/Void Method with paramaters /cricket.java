
/**
 * Write a description of class cricket here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class cricket
{
    private String name;
    
    private int runs;
    
    private int runs_s;
    
    private int balls;
    
    private double avgr;
    
    private double avgb;
    
    private int match;
    
    public cricket(String _name){
        name=_name;
        
    }
    
    public void match(int _runs, int _balls){
        
        runs=runs+_runs;
        
        match=match+1;
        balls=balls+_balls;
        System.out.println(".....Done");
        
        
    }
    
    public void average_runs(){
        System.out.println(runs/match);
    }
    
    public void average_balls(){
        System.out.println(balls/match);
    }
    public void _return_(){
        System.out.print(name+ " scored an average of " + runs + " runs");
        System.out.print(" and bowled " + balls + " times for " + match + " matches");
    }
}
